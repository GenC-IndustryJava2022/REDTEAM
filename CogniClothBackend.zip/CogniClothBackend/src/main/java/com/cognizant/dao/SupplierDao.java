package com.cognizant.dao;


public class SupplierDao {
	
}
