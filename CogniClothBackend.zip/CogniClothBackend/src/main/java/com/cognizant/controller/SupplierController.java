package com.cognizant.controller;

public class SupplierController {

}
